/* =====================================================================
   Classificação Final · views/graficos.js
   #/painel · tela inicial em Gráficos (substitui o antigo Painel de cartões).
   Filtros: período (últimos 3 meses · este ano · tudo) e empresa.
   Cada gráfico baixa em PNG; "Baixar todos" gera um PDF com tudo.
   Os gráficos são SVG desenhados aqui, com as cores do tema na tela e
   sempre em fundo claro nos arquivos baixados.
   ===================================================================== */
(function () {
  'use strict';
  var ui = window.CF.ui, api = window.CF.api, dados = window.CF.dados, esc = ui.esc;
  var CORES = { aprovado: '#3FA66B', backup: '#E9B500', reprovado: '#D9534F', desistencia: '#8a8486' };
  var NOMES = { aprovado: 'Aprovados', backup: 'Backup', reprovado: 'Reprovados', desistencia: 'Desistências' };
  var CLARO = { texto: '#272323', texto2: '#4f4949', texto3: '#8a8486', borda: '#e3dedd', trilho: '#eeeae9', fundo: '#ffffff' };
  var FT = "Poppins, 'Segoe UI', Arial, sans-serif";
  var MESES = ['JAN', 'FEV', 'MAR', 'ABR', 'MAI', 'JUN', 'JUL', 'AGO', 'SET', 'OUT', 'NOV', 'DEZ'];

  function iso(d) { return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
  function hoje() { return iso(new Date()); }
  function dataBR(s) { var p = String(s).slice(0, 10).split('-'); return p[2] + '/' + p[1] + '/' + p[0]; }
  function pct(a, b) { return b ? Math.round(a / b * 100) : 0; }
  function n1(v) { return v == null ? '—' : Number(v).toFixed(1).replace('.', ','); }
  function paletaTela() {
    var cs = getComputedStyle(document.documentElement);
    function v(n, d) { var x = cs.getPropertyValue(n).trim(); return x || d; }
    return { texto: v('--texto', '#272323'), texto2: v('--texto-2', '#4f4949'), texto3: v('--texto-3', '#8a8486'), borda: v('--borda', '#e3dedd'), trilho: v('--surface-2', '#eeeae9'), fundo: 'transparent' };
  }
  function t(x, y, txt, o) {
    o = o || {};
    return '<text x="' + x + '" y="' + y + '" font-family="' + FT + '" font-size="' + (o.tam || 11) + '"' + (o.neg ? ' font-weight="700"' : '') +
      ' text-anchor="' + (o.al || 'start') + '" fill="' + (o.cor || '#000') + '">' + esc(txt) + '</text>';
  }

  /* ---------- Gráficos (SVG) ---------- */
  // degradês usados nos gráficos (cores das situações)
  var GRAD = { aprovado: ['#2f8f57', '#7ee0a2'], backup: ['#b88a1a', '#f0c75e'], reprovado: ['#b8443e', '#ff8a80'], desistencia: ['#6f6869', '#a59d9e'] };
  function defsGrad() {
    return '<defs>' + Object.keys(GRAD).map(function (k) { return '<linearGradient id="gd-' + k + '" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="' + GRAD[k][0] + '"/><stop offset="1" stop-color="' + GRAD[k][1] + '"/></linearGradient>'; }).join('') +
      '<linearGradient id="gd-lar" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#c85a1e"/><stop offset="1" stop-color="#ff9a5a"/></linearGradient>' +
      '<linearGradient id="gd-lar-v" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ee7330" stop-opacity=".35"/><stop offset="1" stop-color="#ee7330" stop-opacity="0"/></linearGradient></defs>';
  }
  function gResultado(procs, P) {   // estilo C: totais no topo + uma barra proporcional por processo
    var keys = ['aprovado', 'backup', 'reprovado', 'desistencia'];
    if (!procs.length) return null;
    var W = 620, s = defsGrad(), tot = { aprovado: 0, backup: 0, reprovado: 0, desistencia: 0 };
    procs.forEach(function (p) { keys.forEach(function (k) { tot[k] += p.cont[k] || 0; }); });
    var bw = (W - 3 * 10) / 4, CORT = { aprovado: '#3FA66B', backup: '#c99512', reprovado: '#D9534F', desistencia: P.texto2 };
    keys.forEach(function (k, i) {   // 4 números grandes
      var x = i * (bw + 10);
      s += '<rect x="' + x + '" y="0" width="' + bw + '" height="58" rx="12" fill="' + P.trilho + '" stroke="' + P.borda + '"/>';
      s += t(x + bw / 2, 30, String(tot[k]), { tam: 22, al: 'middle', neg: true, cor: CORT[k] });
      s += t(x + bw / 2, 48, NOMES[k].toLowerCase(), { tam: 11, al: 'middle', cor: P.texto3 });
    });
    var y = 84;
    procs.forEach(function (p) {
      var n = keys.reduce(function (a, k) { return a + (p.cont[k] || 0); }, 0);
      var nome = (p.empresa + ' · ' + p.vaga); if (nome.length > 62) nome = nome.slice(0, 61) + '…';
      s += t(0, y, nome, { tam: 12.5, cor: P.texto });
      s += t(W, y, n + ' jove' + (n === 1 ? 'm' : 'ns'), { tam: 11, al: 'end', cor: P.texto3 });
      s += '<rect x="0" y="' + (y + 7) + '" width="' + W + '" height="14" rx="7" fill="' + P.trilho + '"/>';
      var x = 0, clip = 'cl' + Math.random().toString(36).slice(2, 8);
      s += '<clipPath id="' + clip + '"><rect x="0" y="' + (y + 7) + '" width="' + W + '" height="14" rx="7"/></clipPath><g clip-path="url(#' + clip + ')">';
      keys.forEach(function (k) {
        var v = p.cont[k] || 0; if (!v || !n) return;
        var w = W * v / n;
        s += '<rect x="' + x.toFixed(1) + '" y="' + (y + 7) + '" width="' + w.toFixed(1) + '" height="14" fill="url(#gd-' + k + ')"/>';
        if (w > 26) s += t((x + w / 2).toFixed(1), y + 18, String(v), { tam: 10, al: 'middle', neg: true, cor: '#ffffff' });
        x += w;
      });
      s += '</g>';
      y += 40;
    });
    var lx = 0, ly = y + 4;   // legenda em duas linhas (cabe em qualquer largura)
    keys.forEach(function (k, i) {
      var cx = (i % 2) * 200, cy = ly + Math.floor(i / 2) * 20;
      s += '<circle cx="' + (cx + 5) + '" cy="' + (cy - 4) + '" r="5" fill="' + GRAD[k][1] + '"/>' + t(cx + 15, cy, NOMES[k], { tam: 11.5, cor: P.texto2 });
    });
    return { svg: s, w: W, h: ly + 26 };
  }
  // Na tela, o "Resultado por processo" é HTML (letra legível no celular); o SVG fica para o PNG e o PDF
  function htmlResultado(procs) {
    var keys = ['aprovado', 'backup', 'reprovado', 'desistencia'], tot = { aprovado: 0, backup: 0, reprovado: 0, desistencia: 0 };
    procs.forEach(function (p) { keys.forEach(function (k) { tot[k] += p.cont[k] || 0; }); });
    return '<div class="gc-kpis">' + keys.map(function (k) { return '<div class="gc-k gc-' + k + '"><b>' + tot[k] + '</b><span>' + NOMES[k].toLowerCase() + '</span></div>'; }).join('') + '</div>' +
      procs.map(function (p) {
        var n = keys.reduce(function (a, k) { return a + (p.cont[k] || 0); }, 0);
        return '<div class="gc-lin"><div class="gc-n"><span>' + esc(ui.titulo(p.empresa) + ' · ' + ui.titulo(p.vaga)) + '</span><small>' + n + ' jove' + (n === 1 ? 'm' : 'ns') + '</small></div><div class="gc-bar">' +
          keys.map(function (k) { var v = p.cont[k] || 0; return v && n ? '<i class="gc-' + k + '" style="width:' + (100 * v / n).toFixed(2) + '%" title="' + NOMES[k] + ': ' + v + '">' + (v / n > .08 ? v : '') + '</i>' : ''; }).join('') + '</div></div>';
      }).join('') +
      '<div class="gc-leg">' + keys.map(function (k) { return '<span><i class="gc-' + k + '"></i>' + NOMES[k] + '</span>'; }).join('') + '</div>';
  }
  function gMeses(serie, P) {
    if (!serie.length) return null;
    var W = 620, H = 210, base = 170, alt = 140, max = 4; serie.forEach(function (x) { max = Math.max(max, x.v); }); max = Math.ceil(max / 4) * 4;
    var passo = serie.length > 1 ? (W - 80) / (serie.length - 1) : 0, s = '';
    for (var i = 0; i <= 4; i++) { var y = base - alt * i / 4; s += '<line x1="36" x2="' + (W - 10) + '" y1="' + y + '" y2="' + y + '" stroke="' + P.borda + '"/>' + t(30, y + 3.5, String(max * i / 4), { tam: 10, al: 'end', cor: P.texto3 }); }
    var pts = serie.map(function (x, k) { return [50 + k * passo, base - x.v / max * alt]; });
    s += '<polyline points="' + pts.map(function (p) { return p[0].toFixed(1) + ',' + p[1].toFixed(1); }).join(' ') + '" fill="none" stroke="#ee7330" stroke-width="3" stroke-linejoin="round"/>';
    serie.forEach(function (x, k) {
      s += '<circle cx="' + pts[k][0].toFixed(1) + '" cy="' + pts[k][1].toFixed(1) + '" r="4.5" fill="#ee7330"/>';
      s += t(pts[k][0].toFixed(1), (pts[k][1] - 9).toFixed(1), String(x.v), { tam: 10.5, al: 'middle', neg: true, cor: P.texto });
      s += t(pts[k][0].toFixed(1), base + 20, x.rot, { tam: 10, al: 'middle', cor: P.texto3 });
    });
    return { svg: s, w: W, h: H };
  }
  function gAreas(areas, P) {
    if (!areas.length) return null;
    var W = 420, lh = 30, H = areas.length * lh + 10, s = defsGrad();
    areas.forEach(function (a, i) {
      var y = 10 + i * lh;
      s += t(0, y + 12, a.nome.length > 16 ? a.nome.slice(0, 15) + '…' : a.nome, { tam: 11.5, cor: P.texto2 });
      s += '<rect x="130" y="' + (y + 3) + '" width="230" height="10" rx="5" fill="' + P.trilho + '"/>';
      s += '<rect x="130" y="' + (y + 3) + '" width="' + (a.v / 5 * 230).toFixed(1) + '" height="10" rx="5" fill="url(#gd-lar)"/>';
      s += t(W - 4, y + 13, n1(a.v), { tam: 12, al: 'end', neg: true, cor: P.texto });
    });
    return { svg: s, w: W, h: H };
  }
  function gEmpresa(ac, P) {
    var partes = [[ac.contratado, '#3FA66B', 'contratados'], [ac.nao, '#D9534F', 'não contratados'], [ac.andamento, '#ee7330', 'em acompanhamento']];
    var tot = ac.contratado + ac.nao + ac.andamento; if (!tot) return null;
    var cx = 80, cy = 80, r = 58, a0 = -90, s = '';
    partes.forEach(function (p) {
      if (!p[0]) return;
      var a1 = a0 + 360 * p[0] / tot;
      if (p[0] === tot) { s += '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="none" stroke="' + p[1] + '" stroke-width="22"/>'; return; }
      var x0 = cx + r * Math.cos(a0 * Math.PI / 180), y0 = cy + r * Math.sin(a0 * Math.PI / 180), x1 = cx + r * Math.cos(a1 * Math.PI / 180), y1 = cy + r * Math.sin(a1 * Math.PI / 180);
      s += '<path d="M' + x0.toFixed(1) + ',' + y0.toFixed(1) + ' A' + r + ',' + r + ' 0 ' + (a1 - a0 > 180 ? 1 : 0) + ' 1 ' + x1.toFixed(1) + ',' + y1.toFixed(1) + '" fill="none" stroke="' + p[1] + '" stroke-width="22"/>';
      a0 = a1;
    });
    var fim = ac.contratado + ac.nao;
    s += t(cx, cy + 2, fim ? pct(ac.contratado, fim) + '%' : '—', { tam: 22, al: 'middle', neg: true, cor: P.texto });
    s += t(cx, cy + 18, 'contratados', { tam: 10, al: 'middle', cor: P.texto3 });
    partes.forEach(function (p, i) { s += '<rect x="178" y="' + (52 + i * 24) + '" width="11" height="11" rx="2" fill="' + p[1] + '"/>' + t(196, 62 + i * 24, p[0] + ' ' + p[2], { tam: 12, cor: P.texto2 }); });
    return { svg: s, w: 360, h: 160 };
  }
  function svgTexto(g, fundo) {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + g.w + ' ' + g.h + '" width="' + g.w + '" height="' + g.h + '">' +
      (fundo ? '<rect width="100%" height="100%" fill="' + fundo + '"/>' : '') + g.svg + '</svg>';
  }
  // SVG → PNG (fundo branco, título no topo), em alta resolução
  function png(g, titulo, sub) {
    return new Promise(function (ok, falha) {
      var esc2 = 2, mt = 64, pad = 24, W = g.w + pad * 2, H = g.h + mt + pad;
      var img = new Image();
      img.onload = function () {
        var cv = document.createElement('canvas'); cv.width = W * esc2; cv.height = H * esc2;
        var cx = cv.getContext('2d'); cx.scale(esc2, esc2);
        cx.fillStyle = '#ffffff'; cx.fillRect(0, 0, W, H);
        cx.fillStyle = '#ee7330'; cx.fillRect(0, 0, 5, H);
        cx.fillStyle = '#272323'; cx.font = 'bold 17px ' + FT; cx.fillText(titulo, pad, 30);
        cx.fillStyle = '#8a8486'; cx.font = '12px ' + FT; cx.fillText(sub, pad, 49);
        cx.drawImage(img, pad, mt, g.w, g.h);
        cv.toBlob(function (b) { ok({ blob: b, url: cv.toDataURL('image/png'), w: W, h: H }); }, 'image/png');
      };
      img.onerror = function () { falha(new Error('Não foi possível gerar a imagem do gráfico.')); };
      img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(window.CF.idioma ? window.CF.idioma.traduzirSVG(svgTexto(g, '#ffffff')) : svgTexto(g, '#ffffff'));
    });
  }

  /* ---------- Tela ---------- */
  window.CF.telas = window.CF.telas || {};
  window.CF.telas.painel = async function (area, ctx) {
    var p = ctx.perfil, admin = p.perfil === 'admin' && (!window.CF.perm || window.CF.perm.pode('graficos_acomp'));
    var primeiroNome = String(p.nome || '').split(' ')[0] || '';
    var st = { periodo: 'ano', empresa: '', tipo: 'todos' }, base;
    area.innerHTML = '<div id="gf"><div class="girando" style="margin:40px auto"></div></div>';
    var box = area.querySelector('#gf');
    try {
      var r = await Promise.all([dados.agenda.carregarTudo(), dados.jovens.todasParticipacoes(),
        admin ? window.CF.sb.rpc('acomp_listar', { p_proc: null }).then(function (x) { return x.error ? [] : x.data; }) : Promise.resolve([]),
        window.CF.agendaG ? window.CF.agendaG.eventosGoogle() : Promise.resolve([]), window.CF.agendaG ? window.CF.agendaG.coresAgendas() : Promise.resolve({}), window.CF.origensDados ? window.CF.origensDados().catch(function () { return null; }) : Promise.resolve(null)]);
      base = { ag: r[0], parts: r[1], acomp: r[2] || [], cls: {}, gev: r[3] || [], coresG: r[4] || {}, ori: r[5] || { escolas: [], cks: [], origens: [] } }; try { base.esp = window.CF.agendaG ? await window.CF.agendaG.especiais() : []; } catch (e) { base.esp = []; }
    } catch (e) { box.innerHTML = '<div class="aviso aviso-erro">' + ui.icone('alerta', 18) + '<span>' + esc(api.traduzErro(e)) + '</span></div>'; return; }
    var ag = base.ag, procs = ag.processos || [], empresas = ag.empresas || [];
    function nomeEmp(id, pid) { if (!id && pid && window.CF.nomeOrigens) return window.CF.nomeOrigens(base.ori, pid); var e = empresas.filter(function (x) { return x.id === id; })[0]; return e ? (e.nome_fantasia || e.razao_social || '') : ''; }
    function diasTurma(tid) { return ag.dias.filter(function (d) { return d.turma_id === tid; }).map(function (d) { return String(d.data).slice(0, 10); }).sort(); }
    function inicioProc(pid) { var ds = []; ag.turmas.filter(function (x) { return x.processo_id === pid; }).forEach(function (x) { ds = ds.concat(diasTurma(x.id)); }); ds.sort(); return ds[0] || null; }
    function desde() {
      var d = new Date();
      if (st.periodo === '3m') { d.setMonth(d.getMonth() - 3); return iso(d); }
      if (st.periodo === 'ano') return d.getFullYear() + '-01-01';
      return '0000-01-01';
    }
    // classificação dos processos com resultado (revisão/liberado), carregada uma vez
    var comResultado = procs.filter(function (x) { return x.situacao === 'revisao' || x.situacao === 'liberado'; });
    await Promise.all(comResultado.map(function (x) { return dados.classificacao.carregar(x.id).then(function (c) { base.cls[x.id] = c; }).catch(function () { /* sem classificação */ }); }));

    function calcular() {
      var d0 = desde(), h = hoje();
      var ps = procs.filter(function (x) { return (!st.empresa || x.empresa_id === st.empresa) && x.situacao !== 'cancelado' && (st.tipo === 'todos' || (x.tipo || 'empresa') === st.tipo); });
      var noPeriodo = ps.filter(function (x) { var i = inicioProc(x.id); return i ? i >= d0 : st.periodo === 'tudo'; });
      var turmasF = ag.turmas.filter(function (x) { return ps.some(function (y) { return y.id === x.processo_id; }); });
      // jovens avaliados: participantes de turmas já realizadas no período
      var porMes = {}, avaliados = 0;
      turmasF.forEach(function (x) {
        var ds = diasTurma(x.id); if (!ds.length || ds[0] > h || ds[0] < d0) return;
        var n = base.parts.filter(function (y) { return y.turma_id === x.id; }).length; avaliados += n;
        var m = ds[0].slice(0, 7); porMes[m] = (porMes[m] || 0) + n;
      });
      var meses = [], ini = st.periodo === 'tudo' ? (Object.keys(porMes).sort()[0] || h.slice(0, 7)) : d0.slice(0, 7), cur = new Date(Number(ini.slice(0, 4)), Number(ini.slice(5, 7)) - 1, 1);
      while (iso(cur).slice(0, 7) <= h.slice(0, 7) && meses.length < 36) { var k = iso(cur).slice(0, 7); meses.push({ rot: MESES[cur.getMonth()] + (st.periodo === 'tudo' || st.periodo === '3m' ? '/' + k.slice(2, 4) : ''), v: porMes[k] || 0 }); cur.setMonth(cur.getMonth() + 1); }
      // resultado por processo (os 8 mais recentes com classificação)
      var res = noPeriodo.filter(function (x) { return base.cls[x.id]; }).sort(function (a, b) { return (inicioProc(b.id) || '').localeCompare(inicioProc(a.id) || ''); }).slice(0, 8).reverse()
        .map(function (x) {
          var c = { aprovado: 0, backup: 0, reprovado: 0, desistencia: 0 };
          base.cls[x.id].jovens.forEach(function (j) { if (c[j.situacao] != null) c[j.situacao]++; });
          return { empresa: nomeEmp(x.empresa_id), vaga: x.vaga || '', cont: c };
        });
      var tot = { aprovado: 0, backup: 0, reprovado: 0, desistencia: 0 }, somaAreas = {}, nAreas = {};
      noPeriodo.forEach(function (x) {
        var c = base.cls[x.id]; if (!c) return;
        c.jovens.forEach(function (j) {
          if (tot[j.situacao] != null) tot[j.situacao]++;
          if (j.situacao === 'desistencia') return;
          Object.keys(j.areas || {}).forEach(function (a) { var v = j.areas[a]; if (v == null) return; somaAreas[a] = (somaAreas[a] || 0) + Number(v); nAreas[a] = (nAreas[a] || 0) + 1; });
        });
      });
      var totAll = tot.aprovado + tot.backup + tot.reprovado + tot.desistencia;
      var areas = Object.keys(somaAreas).sort().map(function (a) { return { nome: a, v: somaAreas[a] / nAreas[a] }; });
      // acompanhamento
      var ac = { contratado: 0, nao: 0, andamento: 0, atrasadas: 0 };
      base.acomp.forEach(function (a) {
        if (!a.aprovado) return;
        if (st.empresa && !ps.some(function (y) { return y.id === a.processo_id; })) return;
        if (a.contratado === true) ac.contratado++; else if (a.contratado === false) ac.nao++; else ac.andamento++;
        if (window.CF.acomp) window.CF.acomp.marcos(a).forEach(function (m) { if (m.estado === 'atrasada') ac.atrasadas++; });
      });
      // próximas turmas e indicadores
      var lim = new Date(); lim.setDate(lim.getDate() + 15); var limISO = iso(lim);
      var proximas = turmasF.map(function (x) { return { t: x, ds: diasTurma(x.id), p: ps.filter(function (y) { return y.id === x.processo_id; })[0] }; })
        .filter(function (x) { return x.ds.length && x.ds[x.ds.length - 1] >= h; });
      // eventos criados direto na Google Agenda também aparecem (marcados)
      var coresG = base.coresG || {}; if (!st.empresa) (base.gev || []).forEach(function (g) { var nm = ((coresG[g.agenda_id] || {}).nome || g.agenda_nome || '').toLowerCase(); if (/assessoramento|feriado|holiday/i.test(nm + ' ' + (g.agenda_id || ''))) return; if (((coresG[g.agenda_id] || {}).proximas) === false) return; if (/anivers/i.test(g.titulo || '')) return; if ((g.data_fim || g.data_ini) >= h) proximas.push({ g: g, ds: g.data_fim && g.data_fim !== g.data_ini ? [g.data_ini, g.data_fim] : [g.data_ini] }); });
      proximas.sort(function (a, b) { return a.ds[0].localeCompare(b.ds[0]); });
      var em15 = proximas.filter(function (x) { return x.ds[0] <= limISO; });   // turmas do sistema e da agenda (as mesmas da lista Próximas turmas)
      return {
        sit: { andamento: ps.filter(function (x) { return x.situacao === 'andamento'; }).length, montagem: ps.filter(function (x) { return x.situacao === 'montagem'; }).length, revisao: ps.filter(function (x) { return x.situacao === 'revisao'; }).length },
        em15: em15, proximas: proximas.slice(0, 10), avaliados: avaliados, nProcPeriodo: noPeriodo.length, tot: tot, totAll: totAll,
        res: res, meses: meses, areas: areas, ac: ac
      };
    }

    var SEM = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'];
    function proximasHTML(d) {   // Próximas turmas · folhinha com o dia, barra da cor da agenda, feriados do sistema na data certa
      var h = hoje(), itens = d.proximas.slice(), fim = itens.length ? itens[itens.length - 1].ds[0] : h;
      var fer = (base.esp || []).filter(function (e) { return e.tipo === 'feriado' && e.data_ini >= h && e.data_ini <= fim; });
      var nT = itens.filter(function (x) { return !x.g; }).length, nE = itens.length - nT;
      var lista = itens.map(function (x) { return { d: x.ds[0], x: x }; }).concat(fer.map(function (e) { return { d: e.data_ini, f: e }; })).sort(function (a, b) { return a.d.localeCompare(b.d) || (a.f ? -1 : 1); });
      function dia(ds) { var dt = new Date(ds + 'T12:00:00'); return '<div class="px-dt' + (ds === h ? ' hoje' : '') + '"><b>' + ds.slice(8, 10) + '</b><span>' + (ds === h ? 'hoje' : SEM[dt.getDay()]) + '</span></div>'; }
      function quando(ds) { return ds.length > 1 ? (ds.length > 2 ? dataBR(ds[0]).slice(0, 5) + ' a ' + dataBR(ds[ds.length - 1]).slice(0, 5) : ds.map(function (z) { return dataBR(z).slice(0, 5); }).join(' e ')) + ' · ' : ''; }
      var cores = base.coresG || {}, usadas = {};
      var corpo = lista.map(function (it) {
        if (it.f) return '<div class="px-fer">⚑ ' + dataBR(it.d).slice(0, 5) + ' · ' + SEM[new Date(it.d + 'T12:00:00').getDay()] + ' · feriado (' + esc(it.f.titulo) + ')</div>';
        var x = it.x;
        if (x.g) {
          var c = cores[x.g.agenda_id] || {}, cor = c.cor || '#2f6fd0', nome = c.nome || x.g.agenda_nome || 'Google'; usadas[nome] = cor;
          return '<div class="px-it" style="--c:' + cor + '">' + dia(x.ds[0]) + '<div class="px-inf"><b>' + esc(x.g.titulo) + '</b><small>' + esc(quando(x.ds) + (x.g.dia_inteiro ? 'dia inteiro' : window.CF.agendaG.hora(x.g.inicio) + ' – ' + window.CF.agendaG.hora(x.g.fim)) + ' · ' + nome) + '</small></div></div>';
        }
        usadas['Turmas do sistema'] = '#2f6fd0';
        return '<div class="px-it" style="--c:#2f6fd0">' + dia(x.ds[0]) + '<div class="px-inf"><b>' + esc(x.t.nome) + '</b><small>' + esc(quando(x.ds) + ui.titulo(nomeEmp(x.p.empresa_id, x.p.id)) + ' · ' + ui.titulo(x.p.vaga)) + '</small></div></div>';
      }).join('');
      if (fer.length) usadas['Feriado'] = '#7d7577';
      return '<section class="card gf-g"><div class="gf-cab"><div><h2>Próximas turmas</h2><p>Turmas do sistema e agendas escolhidas em Integrações</p></div><a class="btn btn-p" href="#/cadastros/turmas">Ver todas</a></div>' +
        (lista.length ? '<div class="px-kp"><div><b>' + nT + '</b><span>turmas</span></div><div><b>' + nE + '</b><span>eventos</span></div><div><b>' + fer.length + '</b><span>feriado' + (fer.length === 1 ? '' : 's') + '</span></div></div>' + corpo +
          '<div class="gc-leg">' + Object.keys(usadas).map(function (k) { return '<span><i style="background:' + usadas[k] + ';border-radius:3px"></i>' + esc(k) + '</span>'; }).join('') + '</div>'
          : '<p class="dica" style="margin:18px 0">Nenhuma turma marcada.</p>') + '</section>';
    }

    var graficos = {};   // id → { titulo, sub, g(paleta) }
    function desenhar() {
      var d = calcular(), P = paletaTela();
      var rotPer = { '3m': 'Últimos 3 meses', ano: 'Este ano', tudo: 'Todo o período' }[st.periodo] + (st.empresa ? ' · ' + nomeEmp(st.empresa) : ' · todas as empresas');
      graficos = {
        resultado: { titulo: 'Resultado por processo', sub: 'Aprovados, backup, reprovados e desistências · ' + rotPer, f: function (Q) { return gResultado(d.res, Q); } },
        meses: { titulo: 'Jovens avaliados por mês', sub: 'Jovens que participaram das turmas · ' + rotPer, f: function (Q) { return gMeses(d.meses, Q); } },
        areas: { titulo: 'Média por área', sub: 'Média das notas dos jovens avaliados · ' + rotPer, f: function (Q) { return gAreas(d.areas, Q); } },
        empresa: { titulo: 'Na empresa (acompanhamento)', sub: 'Jovens aprovados pelas empresas · ' + (st.empresa ? nomeEmp(st.empresa) : 'todas as empresas'), f: function (Q) { return gEmpresa(d.ac, Q); } }
      };
      if (!admin) delete graficos.empresa;
      function cartao(id, extra) {
        var gr = graficos[id], g = gr.f(P);
        if (id === 'resultado' && g) return '<section class="card gf-g"><div class="gf-cab"><div><h2>' + esc(gr.titulo) + '</h2><p>' + esc(gr.sub) + '</p></div><button type="button" class="btn btn-p" data-png="' + id + '">⬇ Baixar</button></div>' + htmlResultado(d.res) + '</section>';
        return '<section class="card gf-g"><div class="gf-cab"><div><h2>' + esc(gr.titulo) + '</h2><p>' + esc(gr.sub) + '</p></div>' +
          (g ? '<button type="button" class="btn btn-p" data-png="' + id + '">⬇ Baixar</button>' : '') + '</div>' +
          (g ? '<div class="gf-svg">' + svgTexto(g).replace('<svg ', '<svg role="img" aria-label="' + esc(gr.titulo) + '" style="width:100%;height:auto" ') + '</div>' : '<p class="dica" style="margin:18px 0">Ainda não há dados para este gráfico no período.</p>') + (extra || '') + '</section>';
      }
      var aprov = d.totAll ? pct(d.tot.aprovado, d.totAll) : null;
      var kpis = [
        ['#ee7330', d.sit.andamento, 'Processos em andamento', d.sit.montagem + ' em montagem · ' + d.sit.revisao + ' em revisão'],
        ['#3f8f9a', d.em15.length, 'Turmas nos próximos 15 dias', d.em15.length ? (d.em15[0].ds[0] === hoje() ? 'a próxima é hoje' : 'a próxima em ' + dataBR(d.em15[0].ds[0])) : 'nenhuma marcada'],
        ['#5b6b8a', d.avaliados, 'Jovens avaliados', 'em ' + d.nProcPeriodo + ' processo' + (d.nProcPeriodo === 1 ? '' : 's') + ' no período'],
        ['#3FA66B', aprov == null ? '—' : aprov + '%', 'Aprovação média', d.totAll ? 'backup ' + pct(d.tot.backup, d.totAll) + '% · desistência ' + pct(d.tot.desistencia, d.totAll) + '%' : 'sem resultados no período']
      ];
      if (admin && st.tipo !== 'escola') kpis.push(['#D9534F', d.ac.atrasadas, 'Avaliações atrasadas', 'acompanhamento das empresas']);
      if (st.tipo !== 'empresa') {   // Profiling Escolas: alunos atendidos, turmas e escolas/CKs no período
        var d0e = desde(), pe = procs.filter(function (x) { return x.tipo === 'escola' && x.situacao !== 'cancelado'; }).filter(function (x) { var i = inicioProc(x.id); return i ? i >= d0e : st.periodo === 'tudo'; });
        var alunos = {}; (base.parts || []).forEach(function (x) { if (pe.some(function (y) { return y.id === x.processo_id; })) alunos[x.jovem_id] = 1; });
        var origs = {}; ((base.ori || {}).origens || []).forEach(function (o) { if (pe.some(function (y) { return y.id === o.processo_id; })) origs[o.escola_id || o.ck_id] = 1; });
        kpis.push(['#2f6fd0', Object.keys(alunos).length, 'Alunos no Profiling Escolas', pe.length + ' turma' + (pe.length === 1 ? '' : 's') + ' · ' + Object.keys(origs).length + ' escola(s)/CK(s)']);
      }
      box.innerHTML =
        '<div class="gf-topo"><div><h1>Olá, ' + esc(primeiroNome) + '!</h1><p class="dica">Gráficos do Projeto Gol Jovens Talentos</p></div>' +
          '<div class="gf-filtros">' + [['empresa', 'Empresas'], ['escola', 'Escolas'], ['todos', 'Todos']].map(function (x) {
            return '<button type="button" class="pt-chip' + (st.tipo === x[0] ? ' on' : '') + '" data-tipo="' + x[0] + '">' + x[1] + '</button>'; }).join('') + '<span class="gf-sep"></span>' + [['3m', '<span class="so-pc">Últimos </span>3 meses'], ['ano', 'Este ano'], ['tudo', 'Tudo']].map(function (x) {
            return '<button type="button" class="pt-chip' + (st.periodo === x[0] ? ' on' : '') + '" data-per="' + x[0] + '">' + x[1] + '</button>'; }).join('') +
            '<select class="entrada gf-emp" id="gf-emp" aria-label="Empresa"><option value="">Empresa: todas</option>' + empresas.slice().sort(function (a, b) { return (a.nome_fantasia || '').localeCompare(b.nome_fantasia || ''); }).map(function (e) {
              return '<option value="' + e.id + '"' + (st.empresa === e.id ? ' selected' : '') + '>' + esc(e.nome_fantasia || e.razao_social) + '</option>'; }).join('') + '</select>' +
            '<button type="button" class="btn btn-pri gf-baixar" id="gf-pdf" title="Baixar todos (PDF)" aria-label="Baixar todos (PDF)">⬇ <span class="so-pc">Baixar todos (PDF)</span></button></div></div>' +
        '<div class="gf-kpis" style="--n:' + kpis.length + '">' + kpis.map(function (k) { return '<div class="card gf-k" style="--c:' + k[0] + '"><b>' + esc(String(k[1])) + '</b><span>' + esc(k[2]) + '</span><small>' + esc(k[3]) + '</small></div>'; }).join('') + '</div>' +
        '<div class="gf-l1">' + cartao('resultado') + cartao('meses') + '</div>' +
        '<div class="gf-l2' + (admin ? '' : ' gf-l2b') + '">' + cartao('areas') + (admin ? cartao('empresa') : '') +
          proximasHTML(d) + '</div>';
      box.querySelectorAll('[data-per]').forEach(function (b) { b.addEventListener('click', function () { st.periodo = b.getAttribute('data-per'); desenhar(); }); });
      box.querySelectorAll('[data-tipo]').forEach(function (b) { b.addEventListener('click', function () { st.tipo = b.getAttribute('data-tipo'); if (st.tipo === 'escola') st.empresa = ''; desenhar(); }); });
      box.querySelector('#gf-emp').addEventListener('change', function () { st.empresa = this.value; desenhar(); });
      box.querySelectorAll('[data-png]').forEach(function (b) {
        b.addEventListener('click', async function () {
          var gr = graficos[b.getAttribute('data-png')], g = gr.f(CLARO);
          try { var im = await png(g, gr.titulo, gr.sub); window.CF.pdf.baixar(im.blob, window.CF.pdf.nomeArquivo(['Grafico', gr.titulo, hoje()], 'png')); }
          catch (e) { ui.toast(e.message, 'erro'); }
        });
      });
      box.querySelector('#gf-pdf').addEventListener('click', function () { baixarTudo(this, d, kpis, rotPer); });
    }

    async function baixarTudo(botao, d, kpis, rotPer) {
      var tx = botao.innerHTML; botao.disabled = true; botao.innerHTML = 'Gerando…';
      try {
        var doc = await window.CF.pdf.novo(), PDF = window.CF.pdf, W = doc.internal.pageSize.getWidth(), H = doc.internal.pageSize.getHeight(), x0 = 21, x1 = W - 10;
        var kolping = await PDF.imagem('assets/img/kolping_light.png');
        function cab() {
          PDF.faixa(doc);
          if (kolping) { var k = Math.min(40 / kolping.w, 9 / kolping.h); doc.addImage(kolping.url, 'PNG', x0, 13, kolping.w * k, kolping.h * k); }
          doc.setFont('P', 'normal'); doc.setFontSize(7.6); doc.setTextColor('#6f696a');
          doc.text('Gráficos · Projeto Gol Jovens Talentos', x1, 18.5, { align: 'right' });
          doc.setDrawColor('#272323'); doc.setLineWidth(0.6); doc.line(x0, 26, x1, 26);
        }
        cab();
        doc.setFont('P', 'bold'); doc.setFontSize(16); doc.setTextColor('#272323'); doc.text('Gráficos', x0, 36);
        doc.setFont('P', 'normal'); doc.setFontSize(9); doc.setTextColor('#6f696a'); doc.text(rotPer + ' · gerado em ' + new Date().toLocaleDateString('pt-BR'), x0, 41.5);
        var y = 47, gap = 3, kw = (x1 - x0 - gap * (kpis.length - 1)) / kpis.length;
        kpis.forEach(function (k, i) {
          var x = x0 + i * (kw + gap);
          doc.setDrawColor('#dcd6d5'); doc.setFillColor('#ffffff'); doc.setLineWidth(0.3); doc.roundedRect(x, y, kw, 22, 2, 2, 'FD');
          doc.setFillColor(k[0]); doc.rect(x, y, 1.4, 22, 'F');
          doc.setFont('P', 'bold'); doc.setFontSize(15); doc.setTextColor('#272323'); doc.text(String(k[1]), x + 4.5, y + 8.5);
          doc.setFontSize(7); doc.text(doc.splitTextToSize(k[2], kw - 7), x + 4.5, y + 13.5);
          doc.setFont('P', 'normal'); doc.setFontSize(6); doc.setTextColor('#6f696a'); doc.text(doc.splitTextToSize(k[3], kw - 7)[0] || '', x + 4.5, y + 19.5);
        });
        y += 29;
        var ids = Object.keys(graficos);
        for (var i = 0; i < ids.length; i++) {
          var gr = graficos[ids[i]], g = gr.f(CLARO); if (!g) continue;
          var im = await png(g, gr.titulo, gr.sub), wmm = x1 - x0, hmm = wmm * im.h / im.w;
          if (hmm > 95) { hmm = 95; wmm = hmm * im.w / im.h; }
          if (y + hmm > H - 26) { doc.addPage(); cab(); y = 32; }
          doc.setDrawColor('#e3dedd'); doc.setLineWidth(0.3); doc.roundedRect(x0, y, x1 - x0, hmm + 2, 2, 2, 'S');
          doc.addImage(im.url, 'PNG', x0 + (x1 - x0 - wmm) / 2, y + 1, wmm, hmm);
          y += hmm + 7;
        }
        var total = doc.getNumberOfPages();
        for (var pg = 1; pg <= total; pg++) { doc.setPage(pg); PDF.rodape(doc, 'Gráficos', pg, total); }
        PDF.baixar(doc.output('blob'), PDF.nomeArquivo(['Graficos Projeto Gol Jovens Talentos', hoje()], 'pdf'));
      } catch (e) { console.error(e); ui.toast(e && e.message ? e.message : 'Não foi possível gerar o PDF.', 'erro'); }
      botao.disabled = false; botao.innerHTML = tx;
    }
    desenhar();
  };
})();
