/* =====================================================================
   Classificação Final · sw.js (service worker)
   Guarda os arquivos do sistema no aparelho para ele abrir sem internet.
   Os dados (Supabase) NUNCA são guardados aqui: só os arquivos do app.
   A cada versão nova, o nome do cache muda e o antigo é apagado.
   ===================================================================== */
var VERSAO = 'cf-4.19.4';
var ARQUIVOS = [
  './',
  'index.html',
  'imprimir.html',
  'manifest.webmanifest',
  'css/app.css',
  'vendor/supabase.js',
  'js/tema.js',
  'js/idioma.js',
  'js/config.js',
  'js/ui.js',
  'js/api.js',
  'js/auth.js',
  'js/foto.js',
  'js/online.js',
  'js/dados.js',
  'js/calendario.js',
  'js/materiais.js',
  'js/documentos.js',
  'vendor/jspdf.umd.min.js',
  'js/pdf.js',
  'vendor/exceljs.min.js',
  'js/excel.js',
  'js/drive.js',
  'js/agenda-google.js',
  'js/importar-eventos.js',
  'assets/fonts/poppins-regular.ttf',
  'assets/fonts/codigo-cracha.woff',
  'assets/fonts/poppins-medium.ttf',
  'assets/fonts/poppins-bold.ttf',
  'vendor/xlsx.mini.min.js',
  'vendor/qrcode.js',
  'js/instalar.js',
  'js/erros.js',
  'js/offline.js',
  'vendor/jsqr.js',
  'js/avisos.js',
  'js/inatividade.js',
  'js/views/telas.js',
  'js/views/minha-conta.js',
  'js/views/cadastros.js',
  'js/testes-motor.js',
  'js/views/banco.js',
  'js/views/testes-tablet.js',
  'js/views/configuracoes.js',
  'js/views/processos.js',
  'js/views/agenda.js',
  'js/views/jovens.js',
  'js/views/avaliar.js',
  'js/views/notas.js',
  'js/views/envios.js',
  'js/views/classificacao.js',
  'js/views/ficha.js',
  'js/views/portal.js',
  'js/views/turmas.js',
  'js/views/graficos.js',
  'js/views/historico.js',
  'js/views/permissoes.js',
  'js/permissoes.js',
  'js/etapas.js',
  'js/vista.js',
  'js/app.js',
  'assets/fonts/poppins-regular.woff2',
  'assets/fonts/poppins-medium.woff2',
  'assets/fonts/poppins-bold.woff2',
  'assets/img/kolping_dark.png',
  'assets/img/gol_dark.png',
  'assets/img/kolping_light.png',
  'assets/img/gol_light.png',
  'assets/img/favicon.png',
  'assets/img/icon-180.png',
  'assets/img/icon-192.png',
  'assets/img/icon-512.png',
  'assets/img/icon-maskable-512.png'
];

self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(VERSAO).then(function (c) { return c.addAll(ARQUIVOS); }));
});

self.addEventListener('activate', function (e) {
  e.waitUntil(
    caches.keys().then(function (nomes) {
      return Promise.all(nomes.filter(function (n) { return n !== VERSAO; }).map(function (n) { return caches.delete(n); }));
    }).then(function () { return self.clients.claim(); })
  );
});

self.addEventListener('message', function (e) {
  if (e.data === 'ATUALIZAR') self.skipWaiting();
});

self.addEventListener('fetch', function (e) {
  if (e.request.url.indexOf('/testes/') >= 0) return;   // o app dos tablets (pasta testes/) tem o próprio cache
  var req = e.request;
  if (req.method !== 'GET') return;
  var url = new URL(req.url);
  if (url.origin !== self.location.origin) return; // Supabase e outros endereços: sempre pela internet

  // Página principal: tenta a internet primeiro (pega a versão mais nova); sem internet, usa a guardada
  if (req.mode === 'navigate') {
    e.respondWith(
      fetch(req).catch(function () { return caches.match('index.html'); })
    );
    return;
  }
  // Demais arquivos do sistema: usa o guardado; se não tiver, busca na internet
  e.respondWith(
    caches.match(req).then(function (r) { return r || fetch(req); })
  );
});
